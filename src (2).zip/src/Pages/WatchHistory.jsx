import React from 'react'

function WatchHistory() {
  return (
    <div>WatchHistory</div>
  )
}
export default WatchHistory